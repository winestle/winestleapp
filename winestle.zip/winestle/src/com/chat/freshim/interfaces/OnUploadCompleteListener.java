package com.chat.freshim.interfaces;

public interface OnUploadCompleteListener {
	void onUploadBegin();
	void onUploadComplete(boolean isComplete, String message);
}
