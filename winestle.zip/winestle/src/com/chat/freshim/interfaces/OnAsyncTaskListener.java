package com.chat.freshim.interfaces;

public interface OnAsyncTaskListener {
	void onTaskBegin();
	void onTaskComplete(boolean isComplete, String message);
}
