package com.chat.freshim.qb;

public class QbConnect {

    public static final String QB_APP_ID = "7927";
    public static final String QB_AUTH_KEY = "3atwZnH4Tx5qBWY";
    public static final String QB_AUTH_SECRET = "7edCptTrQKWcjrj";
}
