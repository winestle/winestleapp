package com.chat.freshim.database;

public class DatabaseFreshIM {
	
    // Database Version
    public static final int DATABASE_VERSION = 1;
    
    // Database Name
    public static final String DATABASE_NAME = "freshim_1";
    
    public static final String DATABASE_NAME_STICKER = "freshim_sticker_1";
    
    public static final String TABLE_STICKER 	= "table_sticker";
    
}